# csv2md.py  12/10/2016  D.J.Whale
#
# Turn a CSV file exported from a spreadsheet, into a markdown table.
# This makes it easier to draw and sort and filter the table,
# and later turn it into markdown for inclusion in github docs.

import sys
import csv

MIN_DASHES = 3


def usage():
    """Show how to use the command"""
    print("usage: csv2md <in_file>")


def table(data):
    # insert table markers around already padded fields
    result = ""
    for d in data:
        result += "| " +d
    return result + " |"


def pad(data, widths):
    """Generate a list of data padded to widths, spaces on the right.
       If data is too wide, truncate it early and insert + at end and generate warning
    """

    result = []
    for i in range(len(data)):
        d = data[i]
        w = widths[i]
        if len(d) > w:
            print("warning: col %d too long: %s" % (i, d))
        result.append(data[i].ljust(widths[i], ' '))
    return result


def lines(headings, widths):
    """Generate a heading line, with lines as long as the headings, and padded to colwidth"""
    lines = []
    for i in range(len(headings)):
        l = len(headings[i])
        if l < MIN_DASHES:
            l = MIN_DASHES
        line = "-" * l
        lines.append(line)

    return pad(lines, widths)


def main(in_name):
    """Process a whole CSV file and generate markdown tables to stdout"""

    with open(in_name) as in_file:
        csvr = csv.reader(in_file, delimiter=',', quotechar='"')
        idx = 0

        for row in csvr:
            if idx == 0: # expect column widths
                widths = [int(i) for i in row]
                idx += 1

            elif idx == 1: # expect column headings
                headings = row
                print(table(pad(headings, widths)))
                print(table(lines(headings, widths)))
                idx += 1

            else: # expect data, or blank line to start a new table
                if len(row) == 0: # blank line
                    # start a new table
                    print("\n") # blank line terminates existing table in md.
                    idx = 0 # start new table

                else: # data line
                    print(table(pad(row, widths)))

        print("\n") # make sure that any table is correctly finished


if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()
    else:
        main(sys.argv[1])

# END
